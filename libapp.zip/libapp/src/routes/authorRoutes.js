const express = require('express');
const authorsRouter = express.Router();
function authorRoute(nav){
    var authors = [
        {
            title: 'tom n jerry',
            author: 'Joseph Barbera',
            genre:'cartoon',
            img: 'tom.jpg'
        },
        {
            title: 'Harry pottar',
            author: 'J k rouling',
            genre:'Fantacy',
            img: 'harry.jpg'
        },
        {
            title: 'paathummayude aade',
            author: 'vaikom muhammad Basheer',
            genre:'drama',
            img: 'pathummayudeaadu.jpg'
        }
    ];
    
    authorsRouter.get('/',function(req,res){
        res.render("authors",{
            nav,
            title:'Library',
            authors
        });
    });
    authorsRouter.get('/:id',function(req,res){
        const id = req.params.id;
        res.render("author",{
            nav,
            title:'Library',
            author: authors[id]
        });
    });
            return authorsRouter;
    }
    module.exports = authorRoute;