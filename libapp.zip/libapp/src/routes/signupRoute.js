const express = require('express');
const signupRouter = express.Router();
function signupRouting(){
    signupRouter.get('/',function(req,res){
        res.render("signup",{
            
            title:'Library',
            
        });
    });
    return signupRouter;
}
module.exports = signupRouting;