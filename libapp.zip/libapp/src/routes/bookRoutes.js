const express = require('express');
const booksRouter = express.Router();
function router(){
var books = [
    {
        title: 'tom n jerry',
        author: 'Joseph Barbera',
        genre:'cartoon',
        img: 'tom.jpg'
    },
    {
        title: 'Harry pottar',
        author: 'J k rouling',
        genre:'Fantacy',
        img: 'harry.jpg'
    },
    {
        title: 'paathummayude aade',
        author: 'vaikom muhammad Basheer',
        genre:'drama',
        img: 'pathummayudeaadu.jpg'
    }
];

booksRouter.get('/',function(req,res){
    res.render("books",{
       
        title:'Library',
        books
    });
});
booksRouter.get('/:id',function(req,res){
    const id = req.params.id;
    res.render("book",{
        
        title:'Library',
        book: books[id]
    });
});
        return booksRouter;
}
module.exports = router;