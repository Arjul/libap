const express = require('express');
const loginRouter = express.Router();
function loginRouting(){
    loginRouter.get('/',function(req,res){
        res.render("login",{
            
            title:'Library',
            
        });
    });
    return loginRouter;
}
module.exports = loginRouting;